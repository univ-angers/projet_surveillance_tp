package com.surveillance.tp.beans;

/**
 * Contient les informations d'une règle liée à un examen spécifique
 */
public class RegleExam {

	private int idRegle;
	private int idExam;
	private String attributs;
	
	public int getIdRegle() {
		return idRegle;
	}
	public void setIdRegle(int idRegle) {
		this.idRegle = idRegle;
	}
	public int getIdExam() {
		return idExam;
	}
	public void setIdExam(int idExam) {
		this.idExam = idExam;
	}
	public String getAttributs() {
		return attributs;
	}
	public void setAttributs(String attributs) {
		this.attributs = attributs;
	}
}
