package Vue;

public interface Observer {
	public void actualiser();
}
